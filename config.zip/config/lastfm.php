<?php

return [

    /*
     * You can get your own last.fm API key at http://www.last.fm/api/account/create.
     */
    'api_key' => env('2194097be55ffce443859bc77914f011'),

];
